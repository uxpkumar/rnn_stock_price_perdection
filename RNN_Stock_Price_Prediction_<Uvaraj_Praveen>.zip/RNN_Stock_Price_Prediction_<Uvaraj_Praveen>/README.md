# RNN-Stock
This project applies Recurrent Neural Networks (RNN) to analyze and predict stock price trends over time. Developed as part of the Master's in Artificial Intelligence and Machine Learning program at IIIT Bangalore (via Upgrad).
